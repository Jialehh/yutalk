<h3>聊天记录管理</h3>
<style>
    .chat-container { margin-bottom: 20px; border: 1px solid #ccc; padding: 10px; border-radius: 5px; }
    .chat-title { font-weight: bold; margin-bottom: 10px; }
    .message { margin-bottom: 5px; padding: 5px; border-radius: 3px; }
    .message .meta { font-size: 0.8em; color: #555; }
</style>
<?php
$chatsDir = '../data/chats/';
if (is_dir($chatsDir)) {
    $chatFiles = glob($chatsDir . '*_messages.txt');
    foreach ($chatFiles as $file) {
        $chatId = basename($file, '_messages.txt');
        echo "<div class='chat-container'>";
        echo "<h4 class='chat-title'>聊天: " . htmlspecialchars($chatId) . "</h4>";
        
        $messages = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($messages as $msgLine) {
            $msgData = json_decode($msgLine, true);
            if ($msgData) {
                $username = htmlspecialchars($msgData['username']);
                $timestamp = htmlspecialchars($msgData['timestamp']);
                $messageText = htmlspecialchars($msgData['message']);
                $type = htmlspecialchars($msgData['type']);

                echo "<div class='message'>";
                echo "<span class='meta'>[{$timestamp}] <strong>{$username}</strong>:</span> ";
                if ($type === 'text') {
                    echo $messageText;
                } elseif ($type === 'image' && isset($msgData['image_path'])) {
                    echo "<img src='../" . htmlspecialchars($msgData['image_path']) . "' alt='Image' style='max-width: 200px; display: block; margin-top: 5px;'>";
                } elseif ($type === 'emoji' && isset($msgData['emoji_path'])) {
                    echo "<img src='../" . htmlspecialchars($msgData['emoji_path']) . "' alt='Emoji' style='width: 24px; height: 24px; vertical-align: middle;'>";
                }
                echo " <a href='delete_message.php?chat_id=" . urlencode($chatId) . "&timestamp=" . urlencode($msgData['timestamp']) . "' onclick=\"return confirm('确定要删除这条消息吗？');\" style='color: red; font-size: 0.8em; margin-left: 10px;'>删除</a>";
                echo "</div>";
            }
        }
        echo "</div>";
    }
}
?>