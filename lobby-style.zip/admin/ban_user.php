<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

if (isset($_GET['user']) && isset($_GET['action'])) {
    $userToModify = $_GET['user'];
    $action = $_GET['action'];
    $usersFile = '../data/users.txt';

    if (file_exists($usersFile)) {
        $users = file($usersFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $updatedUsers = [];

        foreach ($users as $user) {
            $userData = explode('|', $user);
            if ($userData[0] === $userToModify) {
                // Ensure the array has 4 elements
                while(count($userData) < 4) {
                    $userData[] = '';
                }
                $userData[3] = ($action === 'ban') ? 'banned' : 'active';
                $updatedUsers[] = implode('|', $userData);
            } else {
                $updatedUsers[] = $user;
            }
        }

        file_put_contents($usersFile, implode("\n", $updatedUsers));
    }
}

header('Location: dashboard.php?page=users');
exit;
?>