<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

// 获取当前页面参数，默认为 'users'
$page = $_GET['page'] ?? 'users';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>后台管理中心</title>
    <!-- 引入 Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- 引入 Font Awesome 图标库 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
        }
        .sidebar .sidebar-heading {
            padding: 10px 20px;
            font-size: 1.2rem;
            color: #ffffff;
            text-align: center;
            border-bottom: 1px solid #454d55;
            margin-bottom: 20px;
        }
        .sidebar .nav-link {
            color: #adb5bd;
            padding: 12px 20px;
            transition: background-color 0.3s, color 0.3s;
        }
        .sidebar .nav-link:hover {
            background-color: #495057;
            color: #ffffff;
        }
        .sidebar .nav-link.active {
            background-color: #0d6efd;
            color: #ffffff;
            font-weight: bold;
        }
        .sidebar .nav-link i {
            margin-right: 15px;
            width: 20px; /* 固定图标宽度，让文字对齐 */
            text-align: center;
        }
        .main-content {
            margin-left: 260px; /* 等于侧边栏宽度 */
            padding: 20px;
        }
        .header {
            background: #ffffff;
            padding: 10px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .content-area {
            margin-top: 20px;
        }
        .logout-btn {
            color: #dc3545;
            text-decoration: none;
        }
        .logout-btn:hover {
            color: #a71d2a;
        }
    </style>
</head>
<body>
    <div class="sidebar d-flex flex-column p-3 text-white bg-dark">
        <h2 class="sidebar-heading">
            <i class="fas fa-cogs"></i> 后台管理
        </h2>
        <ul class="nav nav-pills flex-column mb-auto">
            <li class="nav-item">
                <a href="dashboard.php?page=users" class="nav-link <?php echo ($page === 'users') ? 'active' : ''; ?>">
                    <i class="fas fa-users"></i>
                    用户管理
                </a>
            </li>
            <li class="nav-item">
                <a href="dashboard.php?page=messages" class="nav-link <?php echo ($page === 'messages') ? 'active' : ''; ?>">
                    <i class="fas fa-comments"></i>
                    聊天记录管理
                </a>
            </li>
        </ul>
        <hr>
        <div class="dropdown">
            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="https://via.placeholder.com/32" alt="" width="32" height="32" class="rounded-circle me-2">
                <strong>管理员</strong>
            </a>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                <li><a class="dropdown-item" href="#">设置</a></li>
                <li><a class="dropdown-item" href="#">个人资料</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="logout.php">退出登录</a></li>
            </ul>
        </div>
    </div>

    <main class="main-content">
        <header class="header d-flex justify-content-between align-items-center mb-4">
            <h1><?php
                if ($page === 'users') {
                    echo '用户管理';
                } elseif ($page === 'messages') {
                    echo '聊天记录管理';
                }
                ?></h1>
            <div>
                <span class="text-muted me-3">欢迎, Admin</span>
                <a href="logout.php" class="logout-btn fw-bold">
                    <i class="fas fa-sign-out-alt"></i> 退出
                </a>
            </div>
        </header>

        <div class="content-area">
            <div class="card shadow-sm">
                <div class="card-body">
                    <?php
                    // 根据页面参数载入对应的管理文件
                    if ($page === 'users' && file_exists('user_management.php')) {
                        include 'user_management.php';
                    } elseif ($page === 'messages' && file_exists('message_management.php')) {
                        include 'message_management.php';
                    } else {
                        // 如果文件不存在，显示一个提示
                        echo '<div class="alert alert-danger">管理模块文件不存在。</div>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </main>

    <!-- 引入 Bootstrap 5 JavaScript Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>