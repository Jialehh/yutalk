<h3>用户管理</h3>
<style>
    table { width: 100%; border-collapse: collapse; }
    th, td { padding: 8px 12px; border: 1px solid #ddd; text-align: left; }
    th { background-color: #f2f2f2; }
    .actions a { margin-right: 10px; text-decoration: none; color: #007bff; }
    .actions a.ban { color: #dc3545; }
</style>
<table>
    <thead>
        <tr>
            <th>用户名</th>
            <th>注册日期</th>
                        <th>状态</th>
            <th>操作</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $usersFile = '../data/users.txt';
        if (file_exists($usersFile)) {
            $users = file($usersFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($users as $user) {
                $userData = explode('|', $user);
                $username = htmlspecialchars($userData[0]);
                $regDate = htmlspecialchars($userData[2]);
                $status = isset($userData[3]) && $userData[3] === 'banned' ? '已封禁' : '正常';
                $actionLink = '';
                if ($status === '正常') {
                    $actionLink = "<a href='ban_user.php?user=" . urlencode($username) . "&action=ban' class='ban' onclick=\"return confirm('确定要封禁该用户吗？');\">封禁</a>";
                } else {
                    $actionLink = "<a href='ban_user.php?user=" . urlencode($username) . "&action=unban' onclick=\"return confirm('确定要解封该用户吗？');\">解封</a>";
                }

                echo "<tr>
                        <td>{$username}</td>
                        <td>{$regDate}</td>
                        <td>{$status}</td>
                        <td class='actions'>
                            {$actionLink}
                        </td>
                      </tr>";
            }
        }
        ?>
    </tbody>
</table>