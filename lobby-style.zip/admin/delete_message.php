<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: index.php');
    exit;
}

if (isset($_GET['chat_id']) && isset($_GET['timestamp'])) {
    $chatId = $_GET['chat_id'];
    $timestampToDelete = $_GET['timestamp'];
    $chatFile = '../data/chats/' . $chatId . '_messages.txt';

    if (file_exists($chatFile)) {
        $messages = file($chatFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $newMessages = [];

        foreach ($messages as $msgLine) {
            $msgData = json_decode($msgLine, true);
            if (!$msgData || $msgData['timestamp'] !== $timestampToDelete) {
                $newMessages[] = $msgLine;
            }
        }

        file_put_contents($chatFile, implode("\n", $newMessages) . "\n");
    }
}

header('Location: dashboard.php?page=messages');
exit;
?>