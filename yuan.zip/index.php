<?php
session_start();

// 检查用户是否已登录
if (!isset($_SESSION['username'])) {
    header('Location: login_page.php');
    exit;
}

$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>雨由Talk</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="app-container">
        <header>
            <img src="Logot.svg" alt="Logo" class="logo-img">
            <h1>雨由Talk</h1>
            <div class="user-info">
                <span>欢迎, <?php echo htmlspecialchars($username); ?></span>
                <button onclick="logout()" style="margin-left: 10px; padding: 5px 10px; background: #dc3545; color: white; border: none; border-radius: 3px; cursor: pointer;">退出</button>
            </div>
        </header>
        <div class="main-content">
            <aside class="sidebar">
                <button id="chatNavButton" class="nav-button active" title="聊天">
                    <img src="chat-icon.svg" alt="Chat">
                </button>
                <button id="meNavButton" class="nav-button" title="我">
                    <img src="me-icon.svg" alt="Me">
                </button>
                <button id="settingsNavButton" class="nav-button" title="设置">
                    <img src="settings-icon.svg" alt="Settings">
                </button>
            </aside>
            <section class="chat-area">
                <div class="chat-list-panel">
                    <div class="search-add-bar">
                        <div class="search-input-container">
                            <img src="se-icon.svg" alt="Search" class="search-icon">
                            <input type="text" id="searchInput" placeholder="搜索">
                        </div>
                        <button id="addChatButton" class="add-button" title="添加聊天">
                            <img src="add-icon.svg" alt="Add">
                        </button>
                    </div>
                    <ul id="chatList" class="chat-list">
                        <li class="chat-item active" data-chat-id="group">
                            <div class="chat-info">
                                <span class="chat-name">群聊</span>
                                <span class="last-message">点击开始聊天</span>
                            </div>
                            <span class="chat-time"></span>
                        </li>
                    </ul>
                </div>
                <div class="message-display-area">
                    <div class="chat-header-bar" id="chatHeaderBar">
                        <span id="currentChatName">群聊</span>
                        <div id="groupAnnouncementContainer" style="display: none; margin-left: auto; align-items: center;">
                            <span id="groupAnnouncementText" style="font-size: 0.9em; color: #555; margin-right: 10px;"></span>
                        </div>
                        <button id="chatSettingsButton" class="chat-header-button" title="聊天设置" style="display: none; margin-left: 10px;">
                            <img src="settings-icon.svg" alt="Chat Settings" style="width: 20px; height: 20px;">
                        </button>
                    </div>
                    <div class="messages" id="messagesContainer">
                        <!-- Messages will appear here -->
                    </div>
                    <div class="settings-panel" id="settingsPanel">
                        <h3>聊天背景设置</h3>
                        <label for="backgroundImageInput">自定义背景图片:</label>
                        <input type="file" id="backgroundImageInput" accept="image/*">
                        <button id="resetBackgroundButton">恢复默认背景</button>
                        
                        <h3 style="margin-top: 20px;">聊天气泡样式</h3>
                        <label for="bubbleStyleSelect">选择气泡样式:</label>
                        <select id="bubbleStyleSelect">
                            <option value="default">默认</option>
                            <option value="cute">可爱</option>
                            <option value="premium">高级</option>
                        </select>

                        <button id="closeSettingsButton" style="margin-top: 20px;">关闭</button>
                    </div>
                    <div class="message-input-area" id="messageInputArea">
                        <input type="file" id="imageUploadInput" accept="image/*" style="display: none;">
                        <button id="attachImageButton" class="attach-image-btn" title="上传图片">
                            <img src="photo-icon.svg" alt="Upload Image">
                        </button>
                        <button id="emojiButton" class="emoji-btn" title="选择表情">
                            <img src="bia-icon.svg" alt="Emoji">
                        </button>
                        <div id="emojiPicker" class="emoji-picker" style="display: none;">
                            <img src="zei.png" alt="zei emoji" data-emoji-name="zei">
                            <img src="zayu.png" alt="zayu emoji" data-emoji-name="zayu">
                            <img src="hello.png" alt="hello emoji" data-emoji-name="hello">
                        </div>
                        <input type="text" id="messageInput" placeholder="在这里输入">
                        <button id="sendMessageButton">发送</button>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <script>
        let currentUser = '<?php echo $username; ?>';

        // 退出登录
        function logout() {
            fetch('auth.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'logout'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'login_page.php';
                }
            });
        }
    </script>
    <script src="script.js"></script>
</body>
</html>