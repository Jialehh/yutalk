document.addEventListener('DOMContentLoaded', () => {
    const chatList = document.getElementById('chatList');
    const searchInput = document.getElementById('searchInput');
    const addChatButton = document.getElementById('addChatButton');
    const messagesContainer = document.getElementById('messagesContainer');
    const messageInput = document.getElementById('messageInput');
    const sendMessageButton = document.getElementById('sendMessageButton');
    const currentChatNameDisplay = document.getElementById('currentChatName');
    const messageInputArea = document.getElementById('messageInputArea');
    const chatNavButton = document.getElementById('chatNavButton');
    const meNavButton = document.getElementById('meNavButton');
    const placeholderText = document.querySelector('.placeholder-text');
    const attachImageButton = document.getElementById('attachImageButton');
    const imageUploadInput = document.getElementById('imageUploadInput');
    const emojiButton = document.getElementById('emojiButton'); // New emoji button
    const emojiPicker = document.getElementById('emojiPicker'); // New emoji picker

    // Settings Panel Elements
    const settingsNavButton = document.getElementById('settingsNavButton');
    const settingsPanel = document.getElementById('settingsPanel');
    const backgroundImageInput = document.getElementById('backgroundImageInput');
    const resetBackgroundButton = document.getElementById('resetBackgroundButton');
    const closeSettingsButton = document.getElementById('closeSettingsButton');
    const messageDisplayArea = document.querySelector('.message-display-area');
    const bubbleStyleSelect = document.getElementById('bubbleStyleSelect'); // Bubble style select
    const groupAnnouncementContainer = document.getElementById('groupAnnouncementContainer');
    const groupAnnouncementText = document.getElementById('groupAnnouncementText');
    // const editAnnouncementButton = document.getElementById('editAnnouncementButton'); // Moved to chat settings

    // New elements for chat settings and context menu
    const chatSettingsButton = document.getElementById('chatSettingsButton');
    const chatSettingsModal = document.getElementById('chatSettingsModal');
    const pinChatOption = document.getElementById('pinChatOption');
    const editGroupAnnouncementOption = document.getElementById('editGroupAnnouncementOption');
    const chatListContextMenu = document.getElementById('chatListContextMenu');
    const contextMenuPinChat = document.getElementById('contextMenuPinChat');

    // Emoji data (could be loaded from a config or dynamically)
    const emojis = [
        { name: 'zei', path: 'assets/zei.png' }, // Assuming emojis are in an 'assets' folder
        { name: 'zayu', path: 'assets/zayu.png' },
        { name: 'hello', path: 'assets/hello.png' }
    ];

    // Function to send an emoji directly as a message
    function sendEmojiAsMessage(emojiPath) {
        if (!currentChatId) return;
        const chat = chats.find(c => c.id === currentChatId);
        if (!chat) return;

        const newMessage = {
            type: 'pure-emoji', // New message type for direct emojis
            content: emojiPath,
            sender: 'me', // Assuming 'me' is the sender
            timestamp: new Date().toISOString()
        };

        chat.messages.push(newMessage);
        renderMessages();
        messagesContainer.scrollTop = messagesContainer.scrollHeight; // Scroll to bottom
    }

    // Populate emoji picker
    function populateEmojiPicker() {
        if (!emojiPicker) return;
        emojiPicker.innerHTML = ''; // Clear existing emojis
        emojis.forEach(emoji => {
            const img = document.createElement('img');
            img.src = emoji.path;
            img.alt = emoji.name;
            img.title = emoji.name;
            img.addEventListener('click', () => {
                // Instead of inserting into input, send directly
                sendEmojiAsMessage(emoji.path);
                emojiPicker.style.display = 'none'; // Hide picker after selection
            });
            emojiPicker.appendChild(img);
        });
    }

    // Load initial bubble style
    let currentBubbleStyle = localStorage.getItem('chatBubbleStyle') || 'default';
    if (bubbleStyleSelect) {
        bubbleStyleSelect.value = currentBubbleStyle;
    }

    // Simulate chat data
    let chats = [ // Add 'pinned: false' to each chat object
        { id: 'ai_assistant', type: 'ai', name: 'AI 助手', messages: [{ text: '你好！我是 AI 助手，有什么可以帮您的吗？', sender: 'ai' }], avatarColor: '#4CAF50', unread: 0, pinned: false },
        { id: 'group1', type: 'group', name: '群聊', messages: [{ text: '欢迎来到群聊!', sender: 'system' }], announcement: '这是一个群公告！', avatarColor: '#FFB300', unread: 0, pinned: false },
        { id: 'user1', type: 'direct', name: '名字', messages: [{ text: '你好呀！', sender: 'other' }], avatarColor: '#78AFFF', unread: 1, pinned: false }
    ];
    let chats_placeholder = [
        { id: 'ai_assistant', type: 'ai', name: 'AI 助手', messages: [{ text: '你好！我是 AI 助手，有什么可以帮您的吗？', sender: 'ai' }], avatarColor: '#4CAF50', unread: 0 },
        { id: 'group1', type: 'group', name: '群聊', messages: [{ text: '欢迎来到群聊!', sender: 'system' }], announcement: '这是一个群公告！', avatarColor: '#FFB300', unread: 0 },
        { id: 'user1', type: 'direct', name: '名字', messages: [{ text: '你好呀！', sender: 'other' }], avatarColor: '#78AFFF', unread: 1 }
    ];
    let currentChatId = null;
    let nextChatId = 2; 

    // --- Render Functions ---
    function renderChatList() {
        chatList.innerHTML = '';
        const searchTerm = searchInput.value.toLowerCase();

        // Sort chats: pinned first, then by original order (or last message time in a real app)
        const sortedChats = [...chats]
            .filter(chat => chat.name.toLowerCase().includes(searchTerm))
            .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));

        sortedChats.forEach(chat => {
                const listItem = document.createElement('li');
                listItem.classList.add('chat-list-item');
                listItem.dataset.chatId = chat.id;

                const avatar = document.createElement('div');
                avatar.classList.add('avatar');
                avatar.style.backgroundColor = chat.avatarColor || getRandomColor();
                avatar.textContent = chat.name.substring(0, 1);

                const nameSpan = document.createElement('span');
                nameSpan.classList.add('chat-name');
                nameSpan.textContent = chat.name;

                if (chat.unread > 0) {
                    const unreadBadge = document.createElement('span');
                    unreadBadge.classList.add('unread-badge'); 
                    unreadBadge.textContent = chat.unread;
                    // Basic styling for unread badge, can be improved in CSS
                    unreadBadge.style.backgroundColor = 'red';
                    unreadBadge.style.color = 'white';
                    unreadBadge.style.padding = '2px 6px';
                    unreadBadge.style.borderRadius = '10px';
                    unreadBadge.style.marginLeft = '8px';
                    unreadBadge.style.fontSize = '0.8em';
                    nameSpan.appendChild(unreadBadge);
                }

                listItem.appendChild(avatar);
                listItem.appendChild(nameSpan);

                if (chat.id === currentChatId) {
                    listItem.classList.add('active');
                }

                if (chat.pinned) {
                    listItem.classList.add('pinned');
                    const pinIcon = document.createElement('span');
                    pinIcon.classList.add('pin-icon'); // Styled in CSS
                    // You might want to add an actual SVG or image for the pin icon here
                    // For now, CSS will handle it if 'pin-icon.svg' is available
                    listItem.appendChild(pinIcon);
                }

                listItem.addEventListener('click', () => selectChat(chat.id));
                listItem.addEventListener('contextmenu', (e) => showChatListContextMenu(e, chat.id));
                chatList.appendChild(listItem);
            });
    }
    
    function applyCurrentBubbleStyle(messageDiv) {
        // Remove any old bubble style classes first to prevent accumulation
        messageDiv.classList.remove('bubble-cute', 'bubble-premium');
    
        if (currentBubbleStyle === 'cute') {
            messageDiv.classList.add('bubble-cute');
        } else if (currentBubbleStyle === 'premium') {
            messageDiv.classList.add('bubble-premium');
        }
        // If 'default', no extra class is needed as base .message.sent/received styles apply.
    }

    function renderMessages() {
        messagesContainer.innerHTML = '';
        if (!currentChatId) {
            currentChatNameDisplay.textContent = '选择一个聊天';
            messageInputArea.style.display = 'none';
            if (placeholderText) placeholderText.style.display = 'block';
            if (groupAnnouncementContainer) groupAnnouncementContainer.style.display = 'none';
            // if (editAnnouncementButton) editAnnouncementButton.style.display = 'none'; // Button removed from header
            if (chatSettingsButton) chatSettingsButton.style.display = 'none'; // Hide chat settings button if no chat selected
            if (emojiPicker) emojiPicker.style.display = 'none'; // Hide emoji picker if no chat selected
            return;
        }
        if (placeholderText) placeholderText.style.display = 'none';

        const chat = chats.find(c => c.id === currentChatId);
        if (!chat) return;

        currentChatNameDisplay.textContent = chat.name;
        messageInputArea.style.display = 'flex';
        if (chatSettingsButton) chatSettingsButton.style.display = 'flex'; // Show chat settings button

        // Handle group announcement display (text only, edit button is in modal)
        if (chat.type === 'group' && groupAnnouncementContainer && groupAnnouncementText) {
            groupAnnouncementContainer.style.display = 'flex';
            groupAnnouncementText.textContent = chat.announcement || '暂无公告';
        } else if (groupAnnouncementContainer) {
            groupAnnouncementContainer.style.display = 'none';
        }

        chat.messages.forEach(msg => {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message');
            
            let senderTypeClass = '';
            if (msg.sender === 'me') {
                senderTypeClass = 'sent';
            } else if (msg.sender === 'system') {
                senderTypeClass = 'system';
            } else if (msg.sender === 'ai') {
                senderTypeClass = 'received-ai-message';
            } else { // 'other'
                senderTypeClass = 'received';
            }
            messageDiv.classList.add(senderTypeClass);

            // Apply additional bubble style class if not 'default' and not a system message and not a pure-emoji message
            if (currentBubbleStyle !== 'default' && msg.sender !== 'system' && msg.type !== 'pure-emoji') {
                applyCurrentBubbleStyle(messageDiv);
            }

            if (msg.type === 'image' && msg.content) {
                const imgElement = document.createElement('img');
                imgElement.src = msg.content;
                imgElement.classList.add('message-image'); // Class for styling
                messageDiv.appendChild(imgElement);
                // Optional: if you want to allow text with images (captions)
                if (msg.text) { 
                    const textSpan = document.createElement('span');
                    textSpan.classList.add('message-image-caption');
                    textSpan.textContent = msg.text;
                    messageDiv.appendChild(textSpan);
                }
            } else if (msg.type === 'pure-emoji' && msg.content) { // Handle pure-emoji messages
                const emojiImgElement = document.createElement('img');
                emojiImgElement.src = msg.content;
                emojiImgElement.classList.add('message-pure-emoji'); // New class for styling direct emojis
                // Ensure it aligns correctly based on sender
                if (msg.sender === 'me') {
                    messageDiv.style.alignSelf = 'flex-end';
                } else {
                    messageDiv.style.alignSelf = 'flex-start';
                }
                messageDiv.appendChild(emojiImgElement);
                // For pure emojis, we don't want the default message bubble styling, so we skip adding senderTypeClass and bubble styles
                // We also remove padding/background that might be on the base .message class if it interferes
                messageDiv.style.background = 'none';
                messageDiv.style.padding = '0';
                messageDiv.style.borderRadius = '0';
                // The animation might still be desired
            } else if (msg.type === 'emoji' && msg.content) { // Handle emoji messages (old way, if still needed)
                const emojiImgElement = document.createElement('img');
                emojiImgElement.src = msg.content; // Path to the emoji image
                emojiImgElement.classList.add('message-emoji-img'); // Class for styling emoji in message
                emojiImgElement.alt = msg.alt || 'emoji'; // Alt text for accessibility
                messageDiv.appendChild(emojiImgElement);
            } else {
                messageDiv.textContent = msg.text;
            }
            messagesContainer.appendChild(messageDiv);
        });
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // --- Event Handlers & Logic ---
    function selectChat(chatId) {
        currentChatId = chatId;
        const chat = chats.find(c => c.id === chatId);
        if (chat) {
            chat.unread = 0;
        }
        renderChatList();
        renderMessages();
        messageInput.focus();
        if (chatSettingsModal) chatSettingsModal.classList.remove('visible'); // Hide settings modal on chat switch
        if (chatListContextMenu) chatListContextMenu.style.display = 'none'; // Hide context menu on chat switch
        if (emojiPicker) emojiPicker.style.display = 'none'; // Hide emoji picker on chat switch
    }

    function sendMessage() {
        const text = messageInput.value.trim();
        if (text === '' || !currentChatId) return;

        const chat = chats.find(c => c.id === currentChatId);
        if (chat) {
            chat.messages.push({ text: text, sender: 'me' });
            renderMessages();

            if (chat.id === 'ai_assistant') {
                getAiResponse(text);
            } else if (chat.id !== 'group1') {
                 setTimeout(() => {
                    const replyText = `回复: "${text.length > 15 ? text.substring(0,15) + '...' : text}"`;
                    chat.messages.push({ text: replyText, sender: 'other' });
                    if (chat.id !== currentChatId) {
                        chat.unread = (chat.unread || 0) + 1;
                    }
                    renderChatList();
                    if (chat.id === currentChatId) renderMessages();
                }, 1000);
            }
        }
        messageInput.value = '';
        messageInput.focus();
    }

    async function getAiResponse(userMessage) {
        const chat = chats.find(c => c.id === currentChatId);
        if (!chat) return;
    
        const apiKey = 'sk-ecozvmqvpaemrvsvwskgzbbluxnotuklyddgeawbikglhmdh'; 
        const apiUrl = 'https://api.siliconflow.cn/v1/chat/completions';
    
        const requestBody = {
            model: "Qwen/Qwen2.5-VL-72B-Instruct", // Ensure this model supports your use case
            messages: [{ role: "user", content: userMessage }],
            stream: false, // Set to true if you want streaming responses
            // Add other parameters as needed by the API and your desired behavior
        };
    
        const options = {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${apiKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        };
    
        try {
            const response = await fetch(apiUrl, options);
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: response.statusText }));
                chat.messages.push({ text: `抱歉，AI 服务出错: ${errorData.error?.message || errorData.message || '未知错误'}`, sender: 'system' });
                renderMessages();
                return;
            }
            const data = await response.json();
            
            if (data.choices && data.choices.length > 0 && data.choices[0].message && data.choices[0].message.content) {
                const aiReply = data.choices[0].message.content;
                chat.messages.push({ text: aiReply, sender: 'ai' });
            } else {
                chat.messages.push({ text: '抱歉，AI 返回了无效的回复。', sender: 'system' });
            }
            renderMessages();
        } catch (error) {
            console.error("AI API Error:", error);
            chat.messages.push({ text: `请求AI失败: ${error.message}`, sender: 'system' });
            renderMessages();
        }
    }

    // --- Event Listeners ---
        const chatName = prompt('输入新聊天的名称:');
        if (chatName && chatName.trim() !== '') {
            const newChatId = `user${nextChatId++}`;
            const isGroupChat = confirm('这是一个群聊吗？');
            chats.unshift({ 
                id: newChatId,
                type: isGroupChat ? 'group' : 'direct',
                name: chatName.trim(),
                messages: [{ text: `与 ${chatName.trim()} 的聊天已开始`, sender: 'system' }],
                announcement: isGroupChat ? '欢迎来到本群！' : undefined, // Default announcement for new groups
                avatarColor: getRandomColor(),
                unread: 0,
                pinned: false // New chats are not pinned by default
            });
            renderChatList();
            selectChat(newChatId); 
        }
    });

    searchInput.addEventListener('input', renderChatList);
    sendMessageButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { // Send on Enter, allow Shift+Enter for newline
            e.preventDefault(); // Prevent default Enter behavior (like newline in some inputs)
            sendMessage();
        }
    });

    // Image Upload Logic - Modified to use renderMessages
    if (attachImageButton && imageUploadInput) {
        attachImageButton.addEventListener('click', () => {
            imageUploadInput.click();
        });

        imageUploadInput.addEventListener('change', (event) => {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    const base64Image = e.target.result;
                    if (currentChatId) {
                        const chat = chats.find(c => c.id === currentChatId);
                        if (chat) {
                            // Add image message to chat data
                            chat.messages.push({ type: 'image', content: base64Image, sender: 'me' });
                            renderMessages(); // Re-render messages to display the image with current bubble style
                        }
                    }
                };
                reader.readAsDataURL(file);
            }
            imageUploadInput.value = ''; 
        });
    }
    
    // Emoji Picker Logic
    if (emojiButton && emojiPicker) {
        // Call populateEmojiPicker to set up click handlers
        populateEmojiPicker();

        emojiButton.addEventListener('click', (event) => {
            event.stopPropagation(); // Prevent click from bubbling to document
            if (emojiPicker.style.display === 'none' || !emojiPicker.style.display) {
                emojiPicker.style.display = 'flex'; // Show the picker
                // Position the picker (optional, if not handled by CSS well enough)
                const inputAreaRect = messageInputArea.getBoundingClientRect();
                emojiPicker.style.bottom = `${window.innerHeight - inputAreaRect.top + 10}px`; // 10px above input area
                emojiPicker.style.left = `${inputAreaRect.left}px`;
            } else {
                emojiPicker.style.display = 'none'; // Hide the picker
            }
        });
    }

    // Sidebar navigation
    chatNavButton.addEventListener('click', () => {
        chatNavButton.classList.add('active');
        meNavButton.classList.remove('active');
        settingsNavButton.classList.remove('active');
        settingsPanel.classList.remove('visible');
        document.querySelector('.chat-list-panel').style.display = 'flex';
        document.querySelector('.message-display-area').style.display = 'flex'; 
        if (placeholderText && !currentChatId) placeholderText.style.display = 'block';
        else if (placeholderText) placeholderText.style.display = 'none';
        if (currentChatId) messageInputArea.style.display = 'flex'; // Show input if chat selected
        renderMessages(); 
    });

    meNavButton.addEventListener('click', () => {
        meNavButton.classList.add('active');
        chatNavButton.classList.remove('active');
        settingsNavButton.classList.remove('active');
        settingsPanel.classList.remove('visible');
        currentChatNameDisplay.textContent = '我的信息';
        messagesContainer.innerHTML = '<p class="placeholder-text">这里是“我”的页面内容。</p>';
        messageInputArea.style.display = 'none';
        if (placeholderText) placeholderText.style.display = 'block';
    });

    settingsNavButton.addEventListener('click', () => {
        settingsPanel.classList.toggle('visible');
        settingsNavButton.classList.add('active');
        chatNavButton.classList.remove('active');
        meNavButton.classList.remove('active');
        // Optionally hide message input when settings are open if it covers content
        // messageInputArea.style.display = !settingsPanel.classList.contains('visible') && currentChatId ? 'flex' : 'none';
    });

    closeSettingsButton.addEventListener('click', () => {
        settingsPanel.classList.remove('visible');
        // Restore correct nav button active state and view
        if (currentChatId || chatNavButton.classList.contains('active')) { // Prioritize chat view if active or a chat is open
            chatNavButton.click();
        } else if (meNavButton.classList.contains('active')) {
            meNavButton.click(); // Should not happen if settings closed to chat or default
        } else { // Default to chat view if no other active
            chatNavButton.click();
        }
    });

    backgroundImageInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file && file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const imageUrl = e.target.result;
                messageDisplayArea.style.backgroundImage = `url(${imageUrl})`;
                localStorage.setItem('chatBackgroundImage', imageUrl);
            };
            reader.readAsDataURL(file);
        }
    });

    resetBackgroundButton.addEventListener('click', () => {
        messageDisplayArea.style.backgroundImage = '';
        localStorage.removeItem('chatBackgroundImage');
    });

    // Bubble Style Select Event Listener
    if (bubbleStyleSelect) {
        bubbleStyleSelect.addEventListener('change', (event) => {
            currentBubbleStyle = event.target.value;
            localStorage.setItem('chatBubbleStyle', currentBubbleStyle);
            renderMessages(); // Re-render messages with the new style
        });
    }

    function loadBackgroundImage() {
        const savedImage = localStorage.getItem('chatBackgroundImage');
        if (savedImage) {
            messageDisplayArea.style.backgroundImage = `url(${savedImage})`;
        }
    }

    function getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    // Initial render and load data
    loadBackgroundImage();

    // Chat Settings Modal Toggle
    if (chatSettingsButton && chatSettingsModal) {
        chatSettingsButton.addEventListener('click', (event) => {
            event.stopPropagation(); // Prevent click from bubbling to document listener if any
            chatSettingsModal.classList.toggle('visible');

            // Adjust position if needed (example: position near the button)
            const buttonRect = chatSettingsButton.getBoundingClientRect();
            chatSettingsModal.style.top = `${buttonRect.bottom + 5}px`; // 5px below the button
            chatSettingsModal.style.right = `${window.innerWidth - buttonRect.right}px`; // Align to the right of the button
            // Ensure it doesn't go off-screen (basic example)
            if (chatSettingsModal.getBoundingClientRect().right > window.innerWidth) {
                chatSettingsModal.style.right = '10px'; // Fallback position
            }
            if (chatSettingsModal.getBoundingClientRect().bottom > window.innerHeight) {
                chatSettingsModal.style.bottom = '10px';
                chatSettingsModal.style.top = 'auto';
            }
        });

        // Hide modal if clicked outside
        document.addEventListener('click', (event) => {
            if (chatSettingsModal.classList.contains('visible') && 
                !chatSettingsModal.contains(event.target) && 
                event.target !== chatSettingsButton && 
                !chatSettingsButton.contains(event.target)) {
                chatSettingsModal.classList.remove('visible');
            }
        });
    }
    renderChatList();
    // Render messages for the initially selected chat (if any) or placeholder
    if (currentChatId) {
        selectChat(currentChatId);
    } else {
        renderMessages(); // This will show the placeholder if no chat is selected
    }

    // Event listener for editing announcement (moved to chat settings modal)
    // if (editAnnouncementButton) { ... }

    // --- Chat Settings Modal Logic ---
    if (chatSettingsButton) {
        chatSettingsButton.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent click from bubbling to document
            if (!currentChatId) return;
            const chat = chats.find(c => c.id === currentChatId);
            if (!chat) return;

            // Update pin option text
            pinChatOption.textContent = chat.pinned ? '取消置顶' : '置顶聊天';

            // Show/hide edit announcement option
            if (chat.type === 'group') {
                editGroupAnnouncementOption.style.display = 'block';
            } else {
                editGroupAnnouncementOption.style.display = 'none';
            }

            // Position and show modal
            const rect = chatSettingsButton.getBoundingClientRect();
            chatSettingsModal.style.top = `${rect.bottom + 5}px`;
            chatSettingsModal.style.right = `${window.innerWidth - rect.right}px`; // Align to the right of the button
            chatSettingsModal.style.left = 'auto';
            chatSettingsModal.classList.add('visible');
        });
    }

    if (pinChatOption) {
        pinChatOption.addEventListener('click', () => {
            if (!currentChatId) return;
            const chat = chats.find(c => c.id === currentChatId);
            if (chat) {
                chat.pinned = !chat.pinned;
                saveChatsToLocalStorage(); // Persist pinned state
                renderChatList();
            }
            chatSettingsModal.classList.remove('visible');
        });
    }

    if (editGroupAnnouncementOption) {
        editGroupAnnouncementOption.addEventListener('click', () => {
            if (!currentChatId) return;
            const chat = chats.find(c => c.id === currentChatId);
            if (chat && chat.type === 'group') {
                const newAnnouncement = prompt('输入新的群公告:', chat.announcement || '');
                if (newAnnouncement !== null) {
                    chat.announcement = newAnnouncement.trim();
                    saveChatsToLocalStorage(); // Persist announcement
                    renderMessages(); // Re-render to update announcement display
                }
            }
            chatSettingsModal.classList.remove('visible');
        });
    }

    // --- Chat List Context Menu Logic ---
    let contextMenuChatId = null;
    function showChatListContextMenu(event, chatId) {
        event.preventDefault();
        event.stopPropagation();
        contextMenuChatId = chatId;
        const chat = chats.find(c => c.id === chatId);
        if (!chat) return;

        contextMenuPinChat.textContent = chat.pinned ? '取消置顶' : '置顶聊天';

        chatListContextMenu.style.top = `${event.clientY}px`;
        chatListContextMenu.style.left = `${event.clientX}px`;
        chatListContextMenu.style.display = 'block';
    }

    if (contextMenuPinChat) {
        contextMenuPinChat.addEventListener('click', () => {
            if (!contextMenuChatId) return;
            const chat = chats.find(c => c.id === contextMenuChatId);
            if (chat) {
                chat.pinned = !chat.pinned;
                saveChatsToLocalStorage();
                renderChatList();
            }
            chatListContextMenu.style.display = 'none';
            contextMenuChatId = null;
        });
    }

    // Hide modals/menus when clicking outside
    document.addEventListener('click', (event) => {
        if (chatSettingsModal && chatSettingsModal.classList.contains('visible') && 
            !chatSettingsModal.contains(event.target) && 
            event.target !== chatSettingsButton && 
            !chatSettingsButton.contains(event.target)) {
            chatSettingsModal.classList.remove('visible');
        }
        if (chatListContextMenu && chatListContextMenu.style.display === 'block' && !chatListContextMenu.contains(event.target)) {
            chatListContextMenu.style.display = 'none';
        }
        // Hide emoji picker if clicked outside
        if (emojiPicker && emojiPicker.style.display === 'flex' && 
            !emojiPicker.contains(event.target) && 
            event.target !== emojiButton && 
            !emojiButton.contains(event.target)) {
            emojiPicker.style.display = 'none';
        }
    });

    // Prevent modals/menus from closing when clicking inside them
    if (chatSettingsModal) {
        chatSettingsModal.addEventListener('click', (e) => e.stopPropagation());
    }
    if (chatListContextMenu) {
        chatListContextMenu.addEventListener('click', (e) => e.stopPropagation());
    }

    // --- Local Storage for Persistence (Optional but good for UX) ---
    function saveChatsToLocalStorage() {
        localStorage.setItem('chatsData', JSON.stringify(chats));
    }

    function loadChatsFromLocalStorage() {
        const savedChats = localStorage.getItem('chatsData');
        if (savedChats) {
            chats = JSON.parse(savedChats);
            // Ensure all chats have the 'pinned' property after loading
            chats.forEach(chat => {
                if (chat.pinned === undefined) {
                    chat.pinned = false;
                }
            });
        } else {
            // Initialize default pinned status if no saved data
            chats.forEach(chat => chat.pinned = chat.pinned || false);
        }
         // Recalculate nextChatId based on loaded chats to avoid ID collisions
        if (chats.length > 0) {
            const maxId = chats.reduce((max, chat) => {
                if (chat.id.startsWith('user')) {
                    const num = parseInt(chat.id.substring(4));
                    return Math.max(max, num);
                }
                return max;
            }, 1);
            nextChatId = maxId + 1;
        }
    }

    // Call initial render functions
    renderChatList();
    renderMessages();
    populateEmojiPicker(); // Populate emoji picker on load
;

let lastMessageId = 0;

// 发送消息
function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const message = messageInput.value.trim();
    
    if (message === '') return;

    fetch('messages.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'send',
            message: message
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageInput.value = '';
            loadMessages(); // Reload messages to show the new one
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error sending message:', error);
    });
}

// 加载消息
function loadMessages() {
    fetch('messages.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'get',
            lastId: lastMessageId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.messages.length > 0) {
            const messagesContainer = document.getElementById('messagesContainer');
            
            data.messages.forEach(msg => {
                const messageDiv = document.createElement('div');
                // currentUser is globally available from index.php
                messageDiv.className = msg.username === currentUser ? 'message sent' : 'message received'; 
                messageDiv.innerHTML = `
                    <div class="message-content">
                        <div class="message-header">
                            <span class="sender-name">${msg.username}</span>
                            <span class="message-time">${msg.timestamp}</span>
                        </div>
                        <div class="message-text">${msg.message}</div>
                    </div>
                `;
                messagesContainer.appendChild(messageDiv);
                lastMessageId = Math.max(lastMessageId, parseInt(msg.id));
            });
            
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        } else if (!data.success) {
            console.error('Error loading messages:', data.message);
        }
    })
    .catch(error => {
        console.error('Error fetching messages:', error);
    });
}

// 事件监听器
// Ensure sendMessageButton and messageInput are available before adding listeners
if (document.getElementById('sendMessageButton')) {
    document.getElementById('sendMessageButton').addEventListener('click', sendMessage);
}
if (document.getElementById('messageInput')) {
    document.getElementById('messageInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
}

// 定期加载新消息
setInterval(loadMessages, 2000);

// 页面加载时初始化 (DOMContentLoaded in index.php already calls loadMessages if needed)
// Re-evaluating if this specific DOMContentLoaded listener for loadMessages is needed here
// as script.js is loaded after DOM is ready and index.php might already call it.
// For now, let's keep it to ensure messages load if index.php's call is removed or changed.
document.addEventListener('DOMContentLoaded', function() {
    loadMessages(); 
});