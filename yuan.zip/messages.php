<?php
session_start();
header('Content-Type: application/json');

// 检查用户是否已登录
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$messagesFile = 'data/messages.txt';
$groupFile = 'data/group.txt';

// 确保文件存在
if (!file_exists($messagesFile)) {
    file_put_contents($messagesFile, '');
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

switch ($action) {
    case 'send':
        sendMessage($input['message']);
        break;
    case 'get':
        getMessages($input['lastId'] ?? 0);
        break;
    case 'getGroupMembers':
        getGroupMembers();
        break;
    default:
        echo json_encode(['success' => false, 'message' => '无效操作']);
}

function sendMessage($message) {
    global $messagesFile;
    
    if (empty($message)) {
        echo json_encode(['success' => false, 'message' => '消息不能为空']);
        return;
    }
    
    $username = $_SESSION['username'];
    $timestamp = date('Y-m-d H:i:s');
    $messageId = time() . rand(1000, 9999);
    
    // 格式: ID|用户名|消息内容|时间戳
    $messageLine = $messageId . '|' . $username . '|' . $message . '|' . $timestamp . "\n";
    file_put_contents($messagesFile, $messageLine, FILE_APPEND);
    
    echo json_encode([
        'success' => true, 
        'message' => '消息发送成功',
        'data' => [
            'id' => $messageId,
            'username' => $username,
            'message' => $message,
            'timestamp' => $timestamp
        ]
    ]);
}

function getMessages($lastId = 0) {
    global $messagesFile;
    
    $messages = [];
    if (file_exists($messagesFile)) {
        $lines = file($messagesFile, FILE_IGNORE_NEW_LINES);
        foreach ($lines as $line) {
            if (empty($line)) continue;
            
            $parts = explode('|', $line, 4);
            if (count($parts) === 4) {
                $messageId = $parts[0];
                if ($messageId > $lastId) {
                    $messages[] = [
                        'id' => $messageId,
                        'username' => $parts[1],
                        'message' => $parts[2],
                        'timestamp' => $parts[3]
                    ];
                }
            }
        }
    }
    
    echo json_encode([
        'success' => true,
        'messages' => $messages
    ]);
}

function getGroupMembers() {
    global $groupFile;
    
    $members = [];
    if (file_exists($groupFile)) {
        $lines = file($groupFile, FILE_IGNORE_NEW_LINES);
        foreach ($lines as $line) {
            if (empty($line)) continue;
            
            $parts = explode('|', $line);
            if (count($parts) >= 2) {
                $members[] = [
                    'username' => $parts[0],
                    'joinTime' => $parts[1]
                ];
            }
        }
    }
    
    echo json_encode([
        'success' => true,
        'members' => $members
    ]);
}
?>